package com.vss.jobmanager.exception;

import org.springframework.http.HttpStatus;

public class BadRequestException extends AbstractException {

	private static final long serialVersionUID = 1L;
	
    public BadRequestException() {
        super(HttpStatus.BAD_REQUEST.getReasonPhrase());
    }

    public BadRequestException(String message) {
        super(message);
    }

    @Override
    public HttpStatus getStatus() {
        return HttpStatus.BAD_REQUEST;
    }
	
}
