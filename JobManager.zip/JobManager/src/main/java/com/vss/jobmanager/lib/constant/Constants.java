package com.vss.jobmanager.lib.constant;

/**
 * Application constants.
 */
public final class Constants {

    // Regex for acceptable logins
    public static final String LOGIN_REGEX = "^(?>[a-zA-Z0-9!$&*+=?^_`{|}~.-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*)|(?>[_.@A-Za-z0-9-]+)$";
    public static final String TRIGGER_PREFIX = "TrigName_";
    public static final String ROUTING_KEY_SUFFIX = ".key";
    //Exception
    public static final int EX_VIOLATION_IN_UNIQUE_INDEX = 2601;
    public static final int EX_VIOLATION_IN_UNIQUE_CONSTRAINT = 2627;
    public static final int EX_SQL_DEADLOCK = 1205;

    private Constants() {}
}
