package com.vss.jobmanager.lib;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;

import static java.util.Objects.nonNull;

@Slf4j
public class AESEncryption {

    private static Cipher cipherEncrypt;
    private static Cipher cipherDecrypt;

    static {
        try {

            log.info("Initial cipher encryption");

            String algorithm = "AES/CBC/PKCS5Padding";
            SecretKey secretKey = getKeyFromPassword("Umoney2023", "1234");
            IvParameterSpec ivParameterSpec = generateIv();

            cipherEncrypt = Cipher.getInstance(algorithm);
            cipherEncrypt.init(Cipher.ENCRYPT_MODE, secretKey, ivParameterSpec);

            cipherDecrypt = Cipher.getInstance(algorithm);
            cipherDecrypt.init(Cipher.DECRYPT_MODE, secretKey, ivParameterSpec);

        } catch (Exception e) {
            log.error("Initial cipher failure", e);
            throw new RuntimeException(e); // Throw to kill application
        }
    }

    private static SecretKey getKeyFromPassword(String password, String salt)
            throws NoSuchAlgorithmException, InvalidKeySpecException {

        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        KeySpec spec = new PBEKeySpec(password.toCharArray(), salt.getBytes(), 65536, 256);
        SecretKey secret = new SecretKeySpec(factory.generateSecret(spec)
                .getEncoded(), "AES");
        return secret;
    }

    private static IvParameterSpec generateIv() throws UnsupportedEncodingException {
//        byte[] iv = new byte[16];
//        new SecureRandom().nextBytes(iv);
        byte[] iv = {0, 2, 0, 0, 3, 9, 0, 7, 0, 0, 1, 0, 0, 2, 30, 0}; // random values
        return new IvParameterSpec(iv);
    }

//    private static String encrypt(String algorithm, String input, SecretKey key,
//                                 IvParameterSpec iv) throws NoSuchPaddingException, NoSuchAlgorithmException,
//            InvalidAlgorithmParameterException, InvalidKeyException,
//            BadPaddingException, IllegalBlockSizeException {
//
//        Cipher cipher = Cipher.getInstance(algorithm);
//        cipher.init(Cipher.ENCRYPT_MODE, key, iv);
//        byte[] cipherText = cipher.doFinal(input.getBytes());
//        return Base64.getEncoder()
//                .encodeToString(cipherText);
//    }
//
//    private static String decrypt(String algorithm, String cipherText, SecretKey key,
//                                 IvParameterSpec iv) throws NoSuchPaddingException, NoSuchAlgorithmException,
//            InvalidAlgorithmParameterException, InvalidKeyException,
//            BadPaddingException, IllegalBlockSizeException {
//
//        Cipher cipher = Cipher.getInstance(algorithm);
//        cipher.init(Cipher.DECRYPT_MODE, key, iv);
//        byte[] plainText = cipher.doFinal(Base64.getDecoder()
//                .decode(cipherText));
//        return new String(plainText);
//    }
//
//    public static String doEncrypt(String input) {
//        String cipherText = input;
//        try {
//            SecretKey key = getSecretKey();
//            IvParameterSpec ivParameterSpec = generateIv();
//            String algorithm = "AES/CBC/PKCS5Padding";
//            cipherText = encrypt(algorithm, input, key, ivParameterSpec);
//        } catch (Exception e) {
//            logger.error(e.getMessage(), e);
//        }
//
//        return cipherText;
//    }
//
//    public static String doDecrypt(String cipherText) {
//        String plainText = cipherText;
//        try {
//            SecretKey key = getSecretKey();
//            IvParameterSpec ivParameterSpec = generateIv();
//            String algorithm = "AES/CBC/PKCS5Padding";
//
//            plainText = decrypt(algorithm, cipherText, key, ivParameterSpec);
//        } catch (Exception e) {
//            logger.error(e.getMessage(), e);
//        }
//
//        return plainText;
//    }

    public static String doEncrypt(String input) {
        if (nonNull(input)) {
            try {
                byte[] cipherText = cipherEncrypt.doFinal(input.getBytes());
                return Base64.getEncoder().encodeToString(cipherText);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        return input;
    }

    public static String doDecrypt(String cipherText) {
        if (nonNull(cipherText)) {
            try {
                byte[] plainText = cipherDecrypt.doFinal(Base64.getDecoder().decode(cipherText));
                return new String(plainText);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        return cipherText;
    }
}
