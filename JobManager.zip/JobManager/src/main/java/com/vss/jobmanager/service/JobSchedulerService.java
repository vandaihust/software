package com.vss.jobmanager.service;

import com.vss.jobmanager.enumuration.JobGroup;
import com.vss.jobmanager.exception.CustomException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.quartz.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.text.ParseException;
import java.util.Map;


@Service
@Slf4j
public class JobSchedulerService {

    @Autowired
    private Scheduler scheduler;

    @PostConstruct
    public void initScheduler() throws SchedulerException {

        if (!scheduler.isStarted())
            scheduler.start();
    }

    // TODO: Check job status for all function
    public void runNow(String jobName, String jobGroup) throws SchedulerException {

        JobDetail jobDetail = getJobDetail(jobName, jobGroup);
        scheduler.triggerJob(jobDetail.getKey());
    }

    public void runNow(String jobName, String jobGroup, Map<String, Object> jobData) throws SchedulerException {

        JobDetail jobDetail = getJobDetail(jobName, jobGroup);
        JobDataMap jobDataMap = new JobDataMap(jobData);
        scheduler.triggerJob(jobDetail.getKey(), jobDataMap);
    }

    public void addJob(String jobName, String description, JobGroup jobGroup, String cronExpression,
                       String triggerName, String username) throws SchedulerException, ParseException {

        // Build jobDetail
        JobKey jobKey = new JobKey(jobName, jobGroup.getName());
        JobDetail jobDetail = buildJobDetail(jobKey, description, jobGroup.getJobClass());

        if (StringUtils.isNotBlank(username))
            jobDetail.getJobDataMap().put("username", username);
        // Build trigger
        Trigger trigger = buildTrigger(jobDetail, triggerName, jobGroup.getName(), cronExpression);

        scheduler.scheduleJob(jobDetail, trigger);
        scheduler.start();
    }

    private Trigger buildTrigger(JobDetail jobDetail, String triggerName, String groupName, String cronExpression) throws ParseException {
        if (ObjectUtils.isNotEmpty(cronExpression)) {
            TriggerKey triggerKey = new TriggerKey(triggerName, groupName);
            return buildScheduleTrigger(triggerKey, cronExpression, jobDetail);
        } else {
            throw new CustomException("Scheduling is invalid!", HttpStatus.BAD_REQUEST);
        }
    }

    public void rescheduleJob(String jobName, JobGroup jobGroup, String triggerName, String cronExpression) throws SchedulerException, ParseException {
        JobDetail jobDetail = getJobDetail(jobName, jobGroup.getName());
        JobKey jobKey = jobDetail.getKey();
        // Build new trigger
        if (scheduler.checkExists(jobKey)) {
            TriggerKey triggerKey = new TriggerKey(triggerName, jobGroup.getName());
            Trigger trigger = scheduler.getTrigger(triggerKey);
            if (trigger == null) {
                throw new CustomException("Fail to reschedule job " + jobName + ", because trigger does not exist!", HttpStatus.BAD_REQUEST);
            } else {
                Trigger newTrigger = buildTrigger(jobDetail, triggerName, jobGroup.getName(), cronExpression);
                // Reschedule job
                scheduler.rescheduleJob(triggerKey, newTrigger);
            }
        } else {
            // Add job
            Trigger trigger = buildTrigger(jobDetail, triggerName, jobGroup.getName(), cronExpression);
            scheduler.scheduleJob(jobDetail, trigger);
        }
        scheduler.start();
    }

    public boolean deleteJob(String jobName, String jobGroup) throws SchedulerException {

        JobDetail jobDetail = getJobDetail(jobName, jobGroup);
        return scheduler.deleteJob(jobDetail.getKey());
    }

    public void pauseJob(String jobName, String jobGroup) throws SchedulerException {

        JobDetail jobDetail = getJobDetail(jobName, jobGroup);
        scheduler.pauseJob(jobDetail.getKey());
    }

    public void resumeJob(String jobName, String jobGroup) throws SchedulerException {

        JobDetail jobDetail = getJobDetail(jobName, jobGroup);
        scheduler.resumeJob(jobDetail.getKey());
    }

    public String unscheduledJob(String triggerName, String jobGroup) throws SchedulerException {
        TriggerKey triggerKey = new TriggerKey(triggerName, jobGroup);

        if (scheduler.checkExists(triggerKey)) {
            scheduler.unscheduleJob(triggerKey);
        }
        return String.format("Success to unscheduled triggerKey %s", triggerKey);
    }

    public JobDetail buildJobDetail(JobKey jobKey, String description, Class<? extends QuartzJobBean> jobClass) {

        return JobBuilder
                .newJob(jobClass)
                .withIdentity(jobKey)
                .withDescription(description)
                .storeDurably(true).build();
    }

    private Trigger buildScheduleTrigger(TriggerKey triggerKey, String cron, JobDetail jobDetail) {

        if (CronExpression.isValidExpression(cron)) {

            return TriggerBuilder
                    .newTrigger().withIdentity(triggerKey)
                    .withSchedule(CronScheduleBuilder.cronSchedule(cron).withMisfireHandlingInstructionDoNothing())
                    .forJob(jobDetail).build();
        } else {
            throw new CustomException("Cron expression is invalid!", HttpStatus.BAD_REQUEST);
        }
    }

    public JobDetail getJobDetail(String jobName, String jobGroupName) throws SchedulerException {

        JobKey jobKey = new JobKey(jobName, jobGroupName);
        JobDetail jobDetail = scheduler.getJobDetail(jobKey);

        if (jobDetail != null) {
            return jobDetail;
        } else {
            throw new CustomException(String.format("Not found jobName %s!", jobName), HttpStatus.NOT_FOUND);
        }
    }

}
