package com.vss.jobmanager;

import com.viettel.unicomviva.properties.MobiquityConfigProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Import;


@SpringBootApplication(scanBasePackages = {"com.vss", "com.viettel.unicomviva"})
@EnableConfigurationProperties({MobiquityConfigProperties.class})
@Import({MobiquityConfigProperties.class})
public class JobManagerApplication {
    public static void main(String[] args) {
        SpringApplication.run(JobManagerApplication.class, args);
    }

}
