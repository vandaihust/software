package com.vss.jobmanager.exception;

import org.springframework.http.HttpStatus;

public abstract class AbstractException extends RuntimeException {
    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    public AbstractException() {
        super();
    }

    public AbstractException(String message) {
        super(message);
    }
    
    public abstract HttpStatus getStatus();
    
}
