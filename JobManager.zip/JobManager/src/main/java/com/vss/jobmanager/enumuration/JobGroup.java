package com.vss.jobmanager.enumuration;

import com.vss.jobmanager.job.*;
import org.springframework.scheduling.quartz.QuartzJobBean;


public enum JobGroup {

    AUTO_TRANSFER_TO_BANK("AutoTransferToBank", AutoTransferToBank.class),
    AUTO_CHARGE_FEE_MONTHLY("AutoChargeFeeMonthly", AutoChargeFeeMonthly.class),
    AUTO_CHARGE_FEE_AGAIN_MONTHLY("AutoChargeFeeAgainMonthly", AutoChargeFeeMonthly.class),
    CHECK_POS_FOLLOW("CheckPosFollow", CheckPosFollow.class),
    CHECK_POS_FOLLOW_AGAIN("CheckPosFollowUnBar", CheckPosFollow.class),

    TRANSFER_TO_BANK_EASY_TAX("TransferToBankEasyTax", TransferToBankEasyTax.class),
    TRANSFER_TO_BANK_EASY_TAX_FOR_TRANSACTION("TransferToBankEasyTaxForTransaction", TransferToBankEasyTax.class),
    ALERT_LOW_BALANCE("AlertLowBalance", AlertLowBalance.class),
    MIGRATE_KYC("MigrateKyc", MigrateKyc.class),
    TRANSACTION_TIMEOUT("TransactionTimeout", TransactionTimeout.class),
    PAY_REWARD("PayReward", PayReward.class),

    PROMOTION_PROMOTION_PAY_NAMPAPA("PromotionPayNampapa", PromotionPayNampapa.class),
    PROMOTION_CASH_BACK_LVI_INSURANCE("CashBackLviInsurance", CashBackLviInsurance.class),
    PROMOTION_CASH_BACK_TRANSFER("CashBackTransfer", CashBackTransfer.class),
    PROMOTION_FREE_CASH_OUT("CashBackGetFreeCashOut", CashBackGetFreeCashout.class),
    PROMOTION_PAYMENT_VIA_QR("PromotionPaymentViaQR", PromotionPaymentViaQR.class),
    PROMOTION_HAPPY_MONDAY_FRIDAY("PromotionHappyMondayFriday", PromotionHappyMondayFriday.class),
    PROMOTION_REGISTER_ACTIVE_MOBILE("PromotionRegisterActiveMobile", PromotionRegisterActiveMobile.class),
    PROMOTION_GET_BANK_TOPUP("PromotionGetBankTopup", GetBankTopup.class),
    PROMOTION_CUSTOMER_RECEIVE_MONEY("PromotionCustomerReceiveMoney", PromotionCustomerReceiveMoney.class),
    PROMOTION_CASH_BACK_BUY_DATA("PromotionCashBackBuyData", CashBackBuyData.class),
    PROMOTION_PAID_INTERNET("PromotionPaidInternet", PromotionPaidInternet.class),
    PROMOTION_EDL("PromotionEdl", ProcessEDL.class),
    TRANSACTION_TIMEOUT_RECONCILE("TransactionTimeoutReconcile", TransactionTimeoutReconcile.class);
    
    final String name;
    final Class<? extends QuartzJobBean> jobClass;

    JobGroup(String name, Class<? extends QuartzJobBean> jobClass) {
        this.name = name;
        this.jobClass = jobClass;
    }

    public static JobGroup getJobGroupFromName(String name) {

        for (JobGroup jobGroup : JobGroup.values()) {

            if (name.equalsIgnoreCase(jobGroup.name)) {
                return jobGroup;
            }
        }
        return null;
    }

    public String getName() {
        return name;
    }

    public Class<? extends QuartzJobBean> getJobClass() {
        return jobClass;
    }

}
