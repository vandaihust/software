package com.vss.jobmanager.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ScheduleDto {
    @NotNull(message = "Job name cannot be null")
    private String jobName;
    private String description;
    @NotNull(message = "Job group name cannot be null")
    private String jobGroupName;
    @NotNull(message = "Cron expression cannot be null")
    private String cronExpression;
    private String username;
}
