package com.vss.jobmanager.config;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.core.NamedInheritableThreadLocal;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class HeaderHolder extends OncePerRequestFilter {

    public static final String USERNAME_HEEADER = "username";
    private static final ThreadLocal<String> AUTHORIZATION = new NamedInheritableThreadLocal<>("Inheritance authorization header");
    private static final ThreadLocal<String> USERNAME = new NamedInheritableThreadLocal<>("Inheritance username header");

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        AUTHORIZATION.set(request.getHeader(HttpHeaders.AUTHORIZATION));
        USERNAME.set(request.getHeader(USERNAME_HEEADER));

        try {
            filterChain.doFilter(request, response);
        } finally {
            AUTHORIZATION.remove();
            USERNAME.remove();
        }

    }

    public static String getAuthorizationHeader() {
        return AUTHORIZATION.get();
    }

    public static String getUsernameHeader() {
        return USERNAME.get();
    }

}
