package com.vss.jobmanager.config.exception;

import com.vss.jobmanager.job.common.response.Response;
import com.vss.jobmanager.job.exception.BadRequestAlertException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@Slf4j
@RestControllerAdvice
public class ControllerExceptionHandler {

  @org.springframework.web.bind.annotation.ExceptionHandler(Exception.class)
  public Response handlerBadRequestAlertException(Exception ex) {
    log.error("handle Exception.class  {}", ex);
    return Response.error5xxx();
  }
  @org.springframework.web.bind.annotation.ExceptionHandler(BadRequestAlertException.class)
  public Response handlerBadRequestAlertException(BadRequestAlertException ex) {
    log.error("handle handlerBadRequestAlertException {}", ex);

    return Response.error4xxx(ex);
  }
}
