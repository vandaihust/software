package com.vss.jobmanager.controller;

import static com.vss.jobmanager.lib.constant.Constants.TRIGGER_PREFIX;

import com.vss.jobmanager.dto.ScheduleDto;
import com.vss.jobmanager.enumuration.JobGroup;
import com.vss.jobmanager.job.dto.JobProcessResponse;
import com.vss.jobmanager.service.JobSchedulerService;

import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;
import org.quartz.JobDetail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/job")
public class JobManagerController {

    @Autowired
    private JobSchedulerService schedulerService;

    @GetMapping("/runNow/{jobName}/{jobGroupName}")
    public ResponseEntity<JobProcessResponse> runNow(@PathVariable("jobName") String jobName, @PathVariable("jobGroupName") String jobGroupName) {
        String msg = "";
        try {
            schedulerService.runNow(jobName, JobGroup.getJobGroupFromName(jobGroupName).getName());

            msg = String.format("Success", jobName);
            log.info(msg);
            return new ResponseEntity<>(new JobProcessResponse(msg), HttpStatus.OK);

        } catch (Exception e) {
            msg = String.format("Failed to run job %s. Cause by: %s", jobName, e.getMessage());
            log.error(msg, e);
        }
        return new ResponseEntity<>(new JobProcessResponse(msg), HttpStatus.OK);
    }

    @GetMapping("/detail")
    public ResponseEntity<?> getDetail(@RequestParam("jobName") String jobName, @RequestParam("jobGroupName") String jobGroupName) {
        try {
            JobDetail detail = schedulerService.getJobDetail(jobName, jobGroupName);
            return new ResponseEntity<>(detail, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.OK);
        }
    }

    @PostMapping("/runNow/{jobName}/{jobGroupName}")
    public ResponseEntity<JobProcessResponse> runNow(@PathVariable("jobName") String jobName, @PathVariable("jobGroupName") String jobGroupName, @RequestBody Map<String, Object> jobData) {
        String msg = "";
        try {
            schedulerService.runNow(jobName, JobGroup.getJobGroupFromName(jobGroupName).getName(), jobData);

            msg = String.format("Success", jobName);
            log.info(msg);
            return new ResponseEntity<>(new JobProcessResponse(msg), HttpStatus.OK);

        } catch (Exception e) {
            msg = String.format("Failed to run job %s. Cause by: %s", jobName, e.getMessage());
            log.error(msg, e);
        }
        return new ResponseEntity<>(new JobProcessResponse(msg), HttpStatus.OK);
    }

    @PostMapping("/addJob")
    public ResponseEntity<JobProcessResponse> addJob(@RequestBody @Valid ScheduleDto scheduleDto) {
        String msg = "";
        try {
            // Create new job
            schedulerService.addJob(
                    scheduleDto.getJobName(),
                    scheduleDto.getDescription(),
                    JobGroup.getJobGroupFromName(scheduleDto.getJobGroupName()),
                    scheduleDto.getCronExpression(), buildTriggerName(scheduleDto.getJobName()),
                    scheduleDto.getUsername()
            );

            msg = String.format("Success", scheduleDto.getJobName());
            log.info(msg);
        } catch (Exception e) {
            msg = String.format("Failed to create new job:%s - Cause by: %s", scheduleDto.getJobName(), e.getMessage());
            log.error(msg, e);
        }
        return new ResponseEntity<>(new JobProcessResponse(msg), HttpStatus.OK);
    }

    @PostMapping("/rescheduleJob")
    public ResponseEntity<String> rescheduleJob(@RequestBody @Valid ScheduleDto scheduleDto) {
        String msg = "";
        try {
            schedulerService.rescheduleJob(scheduleDto.getJobName(), JobGroup.getJobGroupFromName(scheduleDto.getJobGroupName()),
                    buildTriggerName(scheduleDto.getJobName()), scheduleDto.getCronExpression());

            msg = String.format("Success", scheduleDto.getJobName());
            log.info(msg);
            return new ResponseEntity<>(msg, HttpStatus.OK);
        } catch (Exception e) {
            msg = String.format("Failed to reschedule job %s. Cause by: %s", scheduleDto.getJobName(), e.getMessage());
            log.error(msg, e);
        }
        return new ResponseEntity<>(msg, HttpStatus.OK);
    }

    @GetMapping("/delJob/{jobName}/{jobGroupName}")
    public ResponseEntity<String> deleteJob(@PathVariable("jobName") String jobName, @PathVariable("jobGroupName") String jobGroupName) {
        String msg = "";
        try {
            msg = schedulerService.deleteJob(jobName, JobGroup.getJobGroupFromName(jobGroupName).getName())
                    ? String.format("Success", jobName)
                    : String.format("Failed to delete job %s", jobName);

            log.info(msg);
        } catch (Exception e) {
            msg = String.format("Failed to delete job %s. Cause by: %s", jobName, e.getMessage());
            log.error(msg, e);
        }
        return new ResponseEntity<>(msg, HttpStatus.OK);
    }

    @GetMapping("/pauseJob/{jobName}/{jobGroupName}")
    public ResponseEntity<String> pauseJob(@PathVariable("jobName") String jobName, @PathVariable("jobGroupName") String jobGroupName) {
        String msg = "";
        try {
            schedulerService.pauseJob(jobName, JobGroup.getJobGroupFromName(jobGroupName).getName());

            msg = String.format("Success", jobName);
            log.info(msg);
        } catch (Exception e) {
            msg = String.format("Failed to pause job %s. Cause by: %s", jobName, e.getMessage());
            log.error(msg, e);
        }
        return new ResponseEntity<>(msg, HttpStatus.OK);
    }

    @GetMapping("/resumeJob/{jobName}/{jobGroupName}")
    public ResponseEntity<String> resumeJob(@PathVariable("jobName") String jobName, @PathVariable("jobGroupName") String jobGroupName) {
        String msg = "";
        try {
            schedulerService.resumeJob(jobName, JobGroup.getJobGroupFromName(jobGroupName).getName());

            msg = String.format("Success", jobName);
            log.info(msg);

        } catch (Exception e) {
            msg = String.format("Failed to resume job %s. Cause by: %s", jobName, e.getMessage());
            log.error(msg, e);
        }
        return new ResponseEntity<>(msg, HttpStatus.OK);
    }

    @GetMapping("/unscheduledJob/{jobName}/{jobGroupName}")
    public ResponseEntity<String> unscheduledJob(@PathVariable("jobName") String jobName, @PathVariable("jobGroupName") String jobGroupName) {
        String triggerKey = buildTriggerName(jobName);
        String msg = "";
        try {
            msg = schedulerService.unscheduledJob(triggerKey, JobGroup.getJobGroupFromName(jobGroupName).getName());
            log.info(msg);
        } catch (Exception e) {
            msg = String.format("Failed to unscheduled triggerKey %s. Cause by: %s", triggerKey, e.getMessage());
            log.error(msg, e);
        }
        return new ResponseEntity<>(msg, HttpStatus.OK);
    }

    private String buildTriggerName(String jobName) {
        return TRIGGER_PREFIX + jobName;
    }
}
